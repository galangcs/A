# V3n0m Scanner
>  Popular Pentesting scanner in Python3.6 for SQLi/XSS/LFI/RFI and other Vulns

Based on [this](https://github.com/v3n0m-Scanner/V3n0M-Scanner) project

### Usage
````bash
docker run -it v3n0m
````

### Demo  
[![asciicast](https://asciinema.org/a/141830.png)](https://asciinema.org/a/141830)
